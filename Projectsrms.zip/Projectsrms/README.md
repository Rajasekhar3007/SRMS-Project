# 🎓 SRMS - Student Record Management System

A modern, comprehensive web-based application designed to streamline the management of student records, academic progress, and communication between the institution, students, and parents.

![Glassy Teal UI](style.css) 
*(Note: The UI features a unique glassy teal aesthetic)*

## ✨ Key Features

### 👤 For Students
- **Dashboard**: View personal details, roll number, and academic stats.
- **Support**: Raise tickets for any issues directly from the dashboard.
- **Security**: Secure login and password management.

### 👪 For Parents
- **Monitoring**: Real-time access to child's academic performance and attendance.
- **Fee Payment**: Easy interface to handle fee payments.
- **Transparency**: Direct view of student records.

### 🛡️ For Admins
- **Student Management**: Add, Edit, and Delete student records with ease.
- **Ticket Resolution**: View and resolve support tickets raised by students.
- **Secure Access**: Protected admin panel with specific credentials.
- **Clean Interface**: Data is loaded on-demand for a clutter-free experience.

## 🎨 Design & Tech
- **Visuals**: Features a premium "Glassy Teal" UI (RGB 169, 245, 241) with smooth animations and transitions.
- **Stack**: Built with pure **HTML5**, **CSS3**, and **JavaScript**.
- **Storage**: Uses browser `LocalStorage` for data persistence (No backend setup required).

## 🚀 How to Run
1.  **Download** or **Clone** the repository.
2.  Open the folder and double-click `index.html`.
3.  The application opens in your default web browser.

## 🔑 Default Credentials

| Role | Username / ID | Password |
| :--- | :--- | :--- |
| **Admin** | `97903` | `08042007` |
| **Student** | *(As created by Admin)* | Default: `student123` |
| **Parent** | *(Mobile Number)* | Default: `parent123` |

---
*Built with simplicity and elegance in mind.*
